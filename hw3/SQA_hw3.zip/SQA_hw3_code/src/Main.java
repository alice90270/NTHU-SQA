public class Main {
	public static void main(String[] args) {
		UI userInterface = new UI();
		userInterface.start();
	}

}
